import flet as ft
from pages.storage import state_manager
import requests

def send_order(order):
    TOKEN = "8088237896:AAHQ_JcJEJAIyloyZHq68CNdr0KFLEJLpFk"
    chat_id = "7392662313"
    message = f"""
    Новый заказ!\n
    Наименование товара: {order['product']}\n
    Данные игрового аккаунта: {order['login']}\n
    Номер для связи: {order['phone_number']}\n
    Комментарий к заказу: {order['comment']}"""
    url = f"https://api.telegram.org/bot{TOKEN}/sendMessage?chat_id={chat_id}&text={message}"
    requests.get(url).json()


# ! включить проверку полей 
# ! если нет то показать alert с уведомлением о необходимости заполнить все
# ! если всё ок то показать alert 


def cart_page(page: ft.Page, cart):
    good = ft.AlertDialog(
        title=ft.Text("Alert"),
        content=ft.Text("The order has been placed"),
        alignment=ft.alignment.center,
        on_dismiss=lambda e:print ("Dialog dismissed"),
        title_padding=ft.padding.all(25),
        actions=[
            ft.TextButton("Done", on_click=lambda e: page.close(good))
        ],
    )
    bad = ft.AlertDialog(
        title=ft.Text("Alert"),
        content=ft.Text("The cart is empty or not all fields are filled in!"),
        alignment=ft.alignment.center,
        on_dismiss=lambda e:print ("Dialog dismissed"),
        title_padding=ft.padding.all(25),
        actions=[
            ft.TextButton("Done", on_click=lambda e: page.close(bad))
        ],
    )

    if cart:
        good_line = ft.Row(
            [
                ft.Text(cart['name']),
                ft.Text(f"{cart['price']} $"),
                ft.Image(cart['image'], width=120, height=70),
            ], 
            alignment=ft.MainAxisAlignment.CENTER,

        )

    else:
        good_line = ft.Text("Cart is empty", size=32)
     
    login_field = ft.TextField(label="Your game login", width=300)
    phone_field = ft.TextField(label="Phone number", width=300)
    comment_field = ft.TextField(label="Your message", width=300, height=300)
    


    def get_values(e):
        o = {
                'product': state_manager.cart['name'],
                'login': login_field.value,
                'phone_number': phone_field.value,
                'comment': comment_field.value
            }
        send_order(o)
      
    def check(e): 
        if not cart:
            page.open(bad)     
        elif login_field.value and phone_field.value != "":
            page.open(good)
            get_values(e)
        else:
            page.open(bad)
        

        
    return ft.ListView(
        [ 
            ft.Column(
                [
                    good_line,
                    ft.Divider(),
                    login_field,
                    phone_field,  
                    comment_field,
                    ft.ElevatedButton("Confirm", bgcolor='red', on_click=check)
                ],
                alignment=ft.MainAxisAlignment.CENTER,
                horizontal_alignment=ft.CrossAxisAlignment.CENTER,
                spacing=10
            )
        ],
        expand = True
    )
    


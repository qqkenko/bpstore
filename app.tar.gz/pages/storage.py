class StateManager():
    cart = []


state_manager = StateManager()


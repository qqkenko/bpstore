import flet as ft
from pages.storage import state_manager
def home_page(page: ft.Page):
    products = [
        {"name": "DOTA 2",  'description':"✅ БЕЗОПАСНО \n✅ МОМЕНТАЛЬНО", "price": 10.99, 'image': "https://shared.fastly.steamstatic.com/store_item_assets/steam/apps/570/capsule_616x353.jpg?t=1748018387"},
        {"name": "Counter-strike 2", 'description':"✅ БЕЗОПАСНО \n✅ МОМЕНТАЛЬНО", "price": 10.99, 'image': "https://steamuserimages-a.akamaihd.net/ugc/2462990917964003785/9E09A87AE9B299BC1F0FC1CBA9F20DB16289442A/?imw=512&amp;imh=298&amp;ima=fit&amp;impolicy=Letterbox&amp;imcolor=%23000000&amp;letterbox=true"},
        {"name": "Deadlock", 'description':"✅ БЕЗОПАСНО \n✅ МОМЕНТАЛЬНО", "price": 10.99, 'image': "https://habrastorage.org/getpro/habr/upload_files/9cf/5f8/4db/9cf5f84db41381d59a465ccfeab248de.jpg"},
        {"name": "VALORANT", 'description':"✅ БЕЗОПАСНО \n✅ МОМЕНТАЛЬНО", "price": 10.99, 'image': "https://pin.it/4njZxNPVR"},
    ]
    

    def see_more(e, product):
        state_manager.current_product=product
        page.go('/details')

    product_cards = []
    for p in products:
        card = ft.Card(
            content=ft.Column(
                [
                    ft.Image(src=p['image'], width=360, height=150),
                    ft.Text(p['name'], size=18, weight='bold'),
                    ft.Text(p['description'], size=16, weight='bold'),
                    ft.Row(
                        [
                            ft.ElevatedButton("Details", bgcolor='red', on_click=lambda e, product=p: see_more(e, product)),

                            ft.Text(f'Price: {p["price"]} $', size=16),
                        ],
                        alignment=ft.MainAxisAlignment.CENTER,
                        spacing = 10
                    )
                ],
                alignment=ft.MainAxisAlignment.START,
                horizontal_alignment=ft.CrossAxisAlignment.CENTER,
                spacing=10
            ),
            width=360,
            height=200
        )
        product_cards.append(card)
        

    
    return ft.GridView(
        controls=product_cards,
        expand=1,
        runs_count=5,
        max_extent=360,
        child_aspect_ratio=1.0,
        spacing=5,
        run_spacing=5,

    )
